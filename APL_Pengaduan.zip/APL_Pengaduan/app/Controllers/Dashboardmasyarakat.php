<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Dashboardmasyarakat extends BaseController
{
	public function index()
	{
		$data['intro']='<div class="jumbotron mt-5">
		<h3>Selamat datang di Aplikasi Pengaduan Desa Ciherang, '.session()->get('username').'</h3>
		<p>Silahkan gunakan halaman ini untuk menampilkan informasi Pengaduan Masyarakat anda !</p>
	  </div>';
		return view ('Masyarakat/Dashboard', $data);
	}
}
